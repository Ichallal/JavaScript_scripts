function rectangle (){
  let M = parseFloat(document.getElementById("M").value);
 // var M = document.getElementById("M").value;
 // M = +M;
  let mm = parseFloat(document.getElementById("m").value);
  let perimetre = 2 * (M + mm);
  let surface = M * mm;
  let message = "Le périmètre est de : " + perimetre.toFixed(2) + ", et la surface est de : " + surface.toFixed(2);
  console.log(message);
  alert(message);
  document.getElementById("resultat1").innerHTML = message;
}
function cercle (){
  let rayon = parseFloat(document.getElementById("rayon").value);
  let perimetree = 2 * Math.PI * rayon;
  let message = "Périmètre : " + perimetree.toFixed(2);
  console.log(message);
  alert(message);
  document.getElementById("resultat2").innerHTML = message;
}