function Joure() {
    var tab = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    var date = new Date();
    var jour = tab[date.getDay()];
    console.log("on est le jour :" + jour);
    alert("on est le :" + jour);
  }